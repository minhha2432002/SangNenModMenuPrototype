# SangNen Mod Menu Prototype — bản đã rà soát

Dự án Android Studio (Java) tạo nút nổi `SN` và cửa sổ menu có thể kéo thả.

## Đã rà soát / chỉnh sửa
- Kiểm tra cấu trúc Gradle, manifest và hai lớp Java.
- Thêm thao tác kéo cửa sổ bằng thanh tiêu đề.
- Bổ sung xử lý lỗi khi Android từ chối tạo cửa sổ nổi.
- Dọn trạng thái giao diện khi đóng menu.
- Giữ các tùy chọn đánh thường/kỹ năng và mức x2–x100 ở chế độ mô phỏng.

## Giới hạn
Menu không đọc/ghi bộ nhớ game, không chèn mã vào tiến trình, không sửa giao thức mạng và không thay đổi sát thương thật trong game online. Các nút chỉ cập nhật trạng thái giao diện.

## Biên dịch thành APK
Cần máy tính có Android Studio, Android SDK Platform 35 và JDK 17.
1. Giải nén ZIP.
2. Mở thư mục `SangNenModMenuPrototype` trong Android Studio.
3. Chờ Gradle Sync; nếu được yêu cầu, cài Android SDK Platform 35.
4. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug thường nằm ở `app/build/outputs/apk/debug/app-debug.apk`.
6. Cài APK lên điện thoại, mở app, cấp quyền **Hiển thị trên ứng dụng khác**, rồi nhấn **Bật nút nổi**.

## Ghi chú kiểm thử
Môi trường hiện tại không có Android SDK/Gradle cài sẵn, nên đã rà soát và cập nhật mã nguồn nhưng chưa thể xác nhận APK biên dịch thành công. Android Studio sẽ thực hiện bước build thực tế.
