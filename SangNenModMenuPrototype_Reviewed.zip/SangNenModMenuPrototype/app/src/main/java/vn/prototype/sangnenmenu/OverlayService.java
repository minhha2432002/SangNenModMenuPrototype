package vn.prototype.sangnenmenu;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private View bubble, panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private boolean master = true, normal = true, skill = true;
    private String multiplier = "x100";
    private TextView status;
    private final int purple = Color.rgb(117,103,248);
    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                                           : WindowManager.LayoutParams.TYPE_PHONE;
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }
    @Override public void onCreate() {
        super.onCreate(); wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        bubble = text("SN", 17, Color.WHITE); bubble.setTypeface(null, Typeface.BOLD);
        bubble.setGravity(Gravity.CENTER); bubble.setBackground(bg(purple, 100));
        bubbleParams = new WindowManager.LayoutParams(58,58,overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP|Gravity.START; bubbleParams.x = 22; bubbleParams.y = 150;
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                switch(e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=e.getRawX(); downY=e.getRawY(); startX=bubbleParams.x; startY=bubbleParams.y; moved=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx=(int)(e.getRawX()-downX), dy=(int)(e.getRawY()-downY);
                        if(Math.abs(dx)+Math.abs(dy)>6)moved=true;
                        if(moved){bubbleParams.x=Math.max(0,startX+dx);bubbleParams.y=Math.max(80,startY+dy);wm.updateViewLayout(bubble,bubbleParams);} return true;
                    case MotionEvent.ACTION_UP:
                        if(!moved) togglePanel(); return true;
                } return true;
            }
        });
        try {
            wm.addView(bubble,bubbleParams);
        } catch (RuntimeException ex) {
            android.widget.Toast.makeText(this,
                "Không thể tạo nút nổi. Hãy cấp quyền overlay trong Cài đặt.",
                android.widget.Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }
    private void togglePanel() {
        if(panel != null){
            try { wm.removeView(panel); } catch (IllegalArgumentException ignored) {}
            panel=null; status=null; return;
        }
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(22,18,22,18); box.setBackground(bg(Color.rgb(25,28,41),32));
        TextView title=text("SANG NÊN · MOD MENU\nPrototype v1.0.1814",16,Color.WHITE);
        title.setTypeface(null,Typeface.BOLD); box.addView(title);
        Switch main=new Switch(this); main.setText("Kích hoạt menu"); main.setTextColor(Color.WHITE); main.setChecked(master); box.addView(main);
        Switch n=new Switch(this); n.setText("Đánh thường"); n.setTextColor(Color.WHITE); n.setChecked(normal); box.addView(n);
        Switch s=new Switch(this); s.setText("Kỹ năng"); s.setTextColor(Color.WHITE); s.setChecked(skill); box.addView(s);
        TextView label=text("Mức sát thương (chỉ mô phỏng)",12,0xffb7bce0); box.addView(label);
        LinearLayout choices=new LinearLayout(this); choices.setOrientation(LinearLayout.HORIZONTAL);
        for(String m:new String[]{"x2","x5","x10","x50","x100"}) {
            Button b=new Button(this); b.setText(m); b.setTextSize(10); choices.addView(b,new LinearLayout.LayoutParams(0,-2,1));
            b.setOnClickListener(v->{multiplier=m;refreshStatus();});
        }
        box.addView(choices);
        status=text("",11,0xffc4c9df); status.setPadding(0,12,0,0); box.addView(status);
        TextView close=text("Thu gọn  ×",13,0xffaaa6ff); close.setGravity(Gravity.END); close.setPadding(0,12,0,0); box.addView(close);
        main.setOnCheckedChangeListener((v,c)->{master=c;n.setEnabled(c);s.setEnabled(c);refreshStatus();});
        n.setOnCheckedChangeListener((v,c)->{normal=c;refreshStatus();});
        s.setOnCheckedChangeListener((v,c)->{skill=c;refreshStatus();});
        close.setOnClickListener(v->togglePanel());
        n.setEnabled(master);s.setEnabled(master);
        panel=box;
        panelParams=new WindowManager.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*0.78),
            WindowManager.LayoutParams.WRAP_CONTENT,overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity=Gravity.TOP|Gravity.START; panelParams.x=90; panelParams.y=135;
        // Kéo cửa sổ bằng thanh tiêu đề.
        title.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY();
                    startX=panelParams.x; startY=panelParams.y; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int maxX=Math.max(0,getResources().getDisplayMetrics().widthPixels-panel.getWidth());
                    panelParams.x=Math.max(0,Math.min(maxX,startX+(int)(e.getRawX()-downX)));
                    panelParams.y=Math.max(0,startY+(int)(e.getRawY()-downY));
                    try { wm.updateViewLayout(panel,panelParams); }
                    catch (IllegalArgumentException ignored) {}
                    return true;
                }
                return e.getAction()==MotionEvent.ACTION_UP;
            }
        });
        try {
            wm.addView(panel,panelParams);
            refreshStatus();
        } catch (RuntimeException ex) {
            panel=null; status=null;
            android.widget.Toast.makeText(this,
                "Không thể mở menu nổi. Hãy kiểm tra quyền hiển thị trên ứng dụng khác.",
                android.widget.Toast.LENGTH_LONG).show();
        }
    }
    private void refreshStatus() {
        if(status==null)return;
        String selected="";
        if(master){if(normal)selected+="đánh thường ";if(skill)selected+="kỹ năng";}
        status.setText((master?"Menu bật":"Menu tắt")+" · "+(selected.isEmpty()?"không có mục bật":selected.trim())+" · "+multiplier+" (chỉ mô phỏng)");
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_NOT_STICKY;}
    @Override public void onDestroy(){if(wm!=null){if(panel!=null)wm.removeView(panel);if(bubble!=null)wm.removeView(bubble);}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
