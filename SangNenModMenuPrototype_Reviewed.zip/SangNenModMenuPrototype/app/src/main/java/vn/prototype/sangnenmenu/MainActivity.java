package vn.prototype.sangnenmenu;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 101;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        layout.setBackgroundColor(0xff11131d);
        TextView title = new TextView(this);
        title.setText("SANG NÊN · MOD MENU PROTOTYPE");
        title.setTextColor(0xffffffff); title.setTextSize(20);
        layout.addView(title);
        TextView info = new TextView(this);
        info.setText("\nBản thử nghiệm giao diện nổi. Các công tắc chỉ mô phỏng trạng thái, không sửa sát thương game.\n");
        info.setTextColor(0xffc7cbe0); info.setTextSize(15);
        layout.addView(info);
        Button start = new Button(this);
        start.setText("Bật nút nổi");
        layout.addView(start);
        TextView permission = new TextView(this);
        permission.setText("\nAndroid sẽ yêu cầu quyền 'Hiển thị trên ứng dụng khác'. Chỉ cấp quyền nếu bạn muốn dùng nút nổi.");
        permission.setTextColor(0xffaab0c4);
        layout.addView(permission);
        setContentView(layout);
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQUEST_OVERLAY);
            } else startService(new Intent(this, OverlayService.class));
        });
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            startService(new Intent(this, OverlayService.class));
        }
    }
}
